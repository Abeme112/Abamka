// лабораторная работа № 3 БПИ-212  студент Оринчак Святослав Сергеевич
#include <fstream>// библиотека для работы с файлами
#include <cmath>
using namespace std;
int main()
{
    const double PI = 2 * acos(0.); // вычисление числа π
        setlocale(LC_ALL, "Russian"); /* подключение русского языка в консоли*/
    double x = 0.0, y = 0.0, alpha = 0.0;

    ofstream outFile; /* создание потока для вывода информации в файл */
    outFile.open("points.txt"); // связь потока с файлом

    // 1/ цикл по прямой верхней части графика
    y = 0;
    for (x = -4; x <= 4; x++)
        outFile << x << " " << y << endl; // запись в файл

    x = 4;//2.
    for (y = 0; y <= 2 ; y++)
        outFile << x << " " << y << endl; // запись в файл

    y=2;//3/
    for (x = 4; x >= 2 ; x--)
        outFile << x << " " << y << endl; // запись в файл

    for (alpha = 2*PI; alpha >= PI; alpha = alpha - 0.01) //4.
    {
        x = 2*cos(alpha); y = 2+2*sin(alpha);
        outFile << x << " " << y << endl; // запись в файл
    }
    y = 2; //5/
    for (x = -2; x >= -4; x--)
        outFile << x << " " << y << endl; // запись в файл

    x = -4; //6/
    for (y = 2; y >=0; y--)
        outFile << x << " " << y << endl; // запись в файл
}
