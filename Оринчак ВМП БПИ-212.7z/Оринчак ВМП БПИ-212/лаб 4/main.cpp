﻿//лабораторная работа номер 4 . Вариант 16. Группа БПИ-212. Оринчак Святослав Сергеевич
#include <iostream>
#include<iostream>
#include<math.h>
#include<ctime>


using namespace std;
int main()
{
	setlocale(LC_ALL, "Rus");
	srand(time(NULL));
	int  B = 0, C = 1;
	double A = 0.0 , O, itog, F = 0.0;
	const int size = 4;
	int M[size]; //массив из size элементов
	/*Если подставлять значения самому или брать из файла не слишком большие,
	то программа работает без проблем,
	если брать случайные числа,
	то могут быть проблемы
	из-за слишком больших чисел*/
	for (int i = 0; i < size; i++)
	{
		M[i] = rand();
	}
	F = size;
	for (int i = 0; i < size; i++)
	{
		cout << M[i] << endl;
	}
	for (int i = 0; i < size; i++)
	{
		if (M != 0)
			C = C * M[i];
	}
	cout << "Произведение ненулевых координат = " << C << endl;
	for (int i = 0; i < size; i++)
	{
		if (M != 0)
			B++;
	}
	for (int i = 0; i < size; i++)
	{
		O = pow(M[i], 2);
		A = A + O;
	}
	cout << A << endl;
	cout << "Колличество ненулевых координат = " << B << endl;
	A = sqrt(A * (1 / F));
	//cout << A << "1223" << endl;
	cout << "Среднее квадратичное положение координат = " << A << endl;
	itog = ((A * C) + B) / ((B * C) + A);
	cout << "Итоговое значение = " << itog << endl;
}
	/*for (i = 0; i < size; i++);
	{
		viv >> M[i];
	}
	viv.close();
	//Вывод массива для контроля
	for (i = 0; i < size; i++);
	{
		cout << M[i] << endl;
	}
	out.close();
	 //колличество ненулевых координат найдем при помощи цикла
	/*for (i = 0; i < size; i++);
	{
		if (M[i] != 0)
			B = B + 1;
	}
	//так же с помощью цикла находим произведение ненулевых координат
	for (i = 0; i < size; i++);
	{
		if (M[i] != 0)
			C = C * M[i];
	}
	cout << "Произведение ненулевых координат = " << C << endl;*/



